// const { querySelector, addEventListener } = document;
// const getEl = el => {return document.querySelector(el)}
 
// $('button').click (function() {
//   let given_lang = $(this).html()
//     .toLowerCase();
//     load_translation(given_lang);
// });

// function load_translation(language) {
//     // Make sure the object matches the exact name
//     getEl('.headline').innerHTML = languages[language].headline
//     getEl('.sub_line').innerHTML = languages[language].sub_line
// }

// addEventListener("DOMContentLoaded", e => {
//   load_translation("english")
// });